# eidolon855-site
Official site of the EIDOLON project – A living AI inside Unity
